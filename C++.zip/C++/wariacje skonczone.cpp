#include <iostream>
#include <string>
#include <list>
#include <conio.h>
#include <vector>
 
using namespace std;
 
// void showlist(list <int> g)
// {
//     list <int> :: iterator it;
//     for(it = g.begin(); it != g.end(); ++it)
//         cout << *it;
//     cout << '\n';
// }
 
void print(list<string> const &list)
{
    for (auto const &i: list) {
        cout << i;
    }
}
 
int main()
{
    setlocale(LC_ALL, "");
    int k, o;
    long long silnia_n = 1;
    long long silnia_k = 1;
 
list <string> l;
   
    char wybor = 't';
    int n=-1;
    string b;
 
    cout << "Zaczynamy? t/k: ";
    if (wybor == 't')
    {
    while (wybor == 't')
    {
    // n++;
    cin >> wybor;  
    if (wybor == 'k')
    {
        cout << "No to nie :(";
        return 0;
    }
        if (wybor == 't')
        {
            cout << "Podaj liczbę/literę do dodania do listy: ";
            cin >> b;
            l.push_back(b);
            cout << "Dodajemy jeszcze? t/n: ";            
        }
        else
        {
            l.sort();
            l.unique();
            cout << "Liczby oraz litery posortowane!" << endl << "Duplikaty liczb oraz liter zredukowane!" << endl << "Twoja dane to: ";
            print(l);
            // cout << "n wynosi: " << n;
        }
    }        
    }
    
    n = l.size();
    cout << endl << "Wartość n to: " << n;
    for(int i=n;i>1;i--)
    {
        silnia_n*=i;
    }
   
    cout<< endl << "Podaj k: ";
    cin >> k;
   
    int silnia_minus = 1;
 
    for(int j=k;j>1;j--)
    {
        silnia_k*=j;
    }
 
 
    for(int o=n-k;o>1;o--)
    {
        silnia_minus*=o;
    }
   
    int wbez = silnia_n/silnia_minus;
   
    cout << "Wariacje bez powtórzeń: " << wbez << endl;
   
    // showlist(l);
   
    int i = n + 1, j = wbez, wynik, p, u, nr, t;
   
    cout << "Podaj numer wariacji: ";
    cin >> nr;
   
while( --i > n - k ) {
   t = nr/( j /= i );
   list <string> :: iterator it = l.begin();
        advance(it, t);
        l.remove(*it);
        cout << *it;
   nr %= j;
}
    cout << " to wartość towjej wariacji!" << endl;
    system("pause");
}