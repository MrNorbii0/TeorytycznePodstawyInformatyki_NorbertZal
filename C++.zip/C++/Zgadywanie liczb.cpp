#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
int main()
{
    setlocale(LC_ALL, "");
    srand(time(NULL));
    int a = (rand() % 100) + 1;
    // cout << a << endl; // pokazywanie danej liczby
    int x;
    int utry=0;
    
    cout << "Zgadnij liczbę. Uwaga! Pamiętaj, że zakres liczb wynosi od 1 do 100! To twoja " << utry + 1 << " próba! \nWprowadź liczbę: ";
    
    while(x != a)
    {
        utry++;
        cin >> x;
        if (x == a)
        {
            cout << "Udało się! \nZajęło ci to " << utry << " prób!"; 
        }
        
        if (x < a)
        {
            cout << "Podałeś za małą liczbę! Próba " << utry + 1 << "\nWprowadź liczbę: ";
        }
        else if (x > a)
        {
            cout << "Podałeś za dużą liczbę! Próba " << utry + 1 << "\nWprowadź liczbę: ";
        }
    }
    
    
    
    return 0;
}