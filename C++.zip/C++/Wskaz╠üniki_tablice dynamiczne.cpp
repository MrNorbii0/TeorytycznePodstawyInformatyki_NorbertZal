#include <iostream>

using namespace std;

void wypelnij(int* wsk, int rozmiar) {
	for (int i = 0; i < rozmiar; i++) {
		wsk[i] = i+1;
	}
}

void wyswietl(int* wsk, int rozmiar) {
	for (int i = 0; i < rozmiar; i++) {
		cout << wsk[i];
	}
}

int main()
{
	cout << "Podaj rozmiar tablicy: ";
	int n;
	cin >> n;

	int* tablica = new int[n];

	int* pointer = tablica;

	wypelnij(pointer, n);
	wyswietl(pointer, n);

}

int main()
{
	int liczba = 5;

	int* pointer = &liczba;

	cout << "Liczba: " << *pointer << " | Adres: " << pointer;
}

void wypelnij(int tab[], int size) {
	for (int i = 0; i < size; i++) {
		tab[i] = i+1;
	}
}

void wyswietl(int tab[], int size) {
	for (int i = 0; i < size; i++) {
		cout << tab[i];
	}
}

int main()
{
	cout << "Podaj rozmiar tablicy: ";
	int n;
	cin >> n;

	int* tablica = new int[n];

	wypelnij(tablica, n);
	wyswietl(tablica, n);
}


void wypelnij(int* wsk, int rozmiar) {
	for (int i = 0; i < rozmiar; i++) {
		wsk[i] = i + 1;
	}
}

void wyswietl(int* wsk, int rozmiar) {
	for (int i = 0; i < rozmiar; i++) {
		cout << wsk[i];
	}
}

int main()
{
	cout << "Podaj wielko�� tablicy: ";
	int n;
	cin >> n;

	int* tablica = new int[n];

	int* pointer = tablica;

	wypelnij(pointer, n);
	wyswietl(pointer, n);
}

void wypelnij(int tab[], int size) {
	for (int i = 0; i < size; i++) {
		tab[i] = i + 1;
	}
}

void wyswietl(int tab[], int size) {
	for (int i = 0; i < size; i++) {
		cout << (tab[i] * 5);
	}
}

int main()
{
	int tablica[10];

	wypelnij(tablica, 10);
	wyswietl(tablica, 10);




}

int main()
{
	int liczba = 5;

	int* pointer = &liczba;

	cout << "Liczba to: " << *pointer << " o adresie: " << pointer;
}