    #include <iostream>

using namespace std;

int main()
{
    int l;
    int h;
    int mid;
    bool done = false;
    int szukana;
    int check;
    int proba = 0;
    
    do
    {
        cout << "Podaj początek zakresu: ";
        cin >> l;
        cout << "Podaj koniec zakresu: ";
        cin >> h;
        if (l > h)
        {
            cout << "Koniec zakresu nie może być większy od początku! Spróbuj ponownie!\n";
        }
    } while (l > h);
    
    
    while (!done)
    {
        mid = (l + h)/2;
        cout << "Czy jest to liczba? " << mid << endl;
        cout << "0.Tak\n1.Moja jest mniejsza\n2.Moja jest większa\n";
        proba++;
        cin >> check;
        
        if(mid==h)
        {
            cout << mid << " to finalna liczba! Zgadłem w " << proba << " próbach!" ;
            return 0;
        }
		
		if(check == 0){
		   mid == szukana;
		    cout << "Wygrałeś w " << proba << " próbach!";
			return mid;
		}
		else if(check == 1){
		    mid > szukana;
			h = mid - 1;
		}
		else if(check == 2){
		    mid < szukana;
			l = mid + 1;
		}
		 
    }
}