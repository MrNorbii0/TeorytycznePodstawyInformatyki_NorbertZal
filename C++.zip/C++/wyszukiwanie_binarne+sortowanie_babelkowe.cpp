#include <iostream>

using namespace std;

int wyszukiwanieBinarne(int t[], int start, int end, int val)
{
    int mid;
    mid = start + (end - start) / 2;
    
    if (start > end)
    {
        return -1;
    }
    
    if (t[mid] == val)
    {
        return mid;
    }
    else if (t[mid] < val)
    {
        return wyszukiwanieBinarne(t, mid + 1, end, val);
    }
    else
    {
        return wyszukiwanieBinarne(t, start, mid - 1, val);
    }
}

void sortowanieBabelkowe(int t[], int n) {
	int i, j;
	float temp;
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if (t[j] < t[i]) {
				temp = t[i];
				t[i] = t[j];
				t[j] = temp; 
			} 
		}
	}
}

void tablicaWyjscie(int t[], int n) {
	for (int i = 0; i < n; i++) {
		cout << "element[" << i << "] = " << t[i] << endl; 
	}
}

void tablicaWejscie(int t[], int n) {
	for (int i = 0; i < n; i++) {
		cout << "element[" << i << "] = ";
		cin >> t[i]; 
	} 
}

int main()
{

    int p;
    cout << "Wprowadź liczbę elementów tablicy: ";
    cin >> p;
    int *tablica = new int[p];
    cout << endl << "Wprowadź " << p << " liczb do posortowania: " << endl;
    
    for (int x = 0; x < p; x++)
    {
        cin >> tablica[x];
    }
    cout << endl;
    
    cout << "Zawartość tablicy wejściowej: " << endl;
	tablicaWyjscie(tablica, p); 
    
    sortowanieBabelkowe(tablica, p);
    
    cout << "Zawartosć tablicy posortowanej: " << endl;
	tablicaWyjscie(tablica, p); 
    
    int liczba;
    cout << endl << "Podaj szukaną liczbę: ";
    cin >> liczba;
    
    // cout << tablica[0] << "&&" << tablica[p - 1] << end;

    int indeks = wyszukiwanieBinarne(tablica, 0, p - 1, liczba);
    
    if (indeks != -1)
    {
        cout << endl << "Pozycja (inedeks) szukanej liczby w tablicy: " << indeks << endl;
        cout << "Wartość elemntu tablicy o indeksie " << indeks << ": " << tablica[indeks] << endl; 
    }
    else
    {
        cout << "Zadanej liczby nie znaleziono!" << endl;
    }

    return 0;
}