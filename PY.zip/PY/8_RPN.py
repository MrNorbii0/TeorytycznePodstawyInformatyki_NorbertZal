def to_rpn(expr):
    stack = []
    output = []
    priority = {"+": 1, "-": 1, "*": 2, "/": 2}

    for ch in expr.replace(" ", ""):
        if ch.isdigit():
            output.append(ch)

        elif ch in priority:
            while stack and stack[-1] in priority and priority[stack[-1]] >= priority[ch]:
                output.append(stack.pop())
            stack.append(ch)

        elif ch == "(":
            stack.append(ch)

        elif ch == ")":
            while stack[-1] != "(":
                output.append(stack.pop())
            stack.pop()

    while stack:
        output.append(stack.pop())

    return " ".join(output)+" ="

print(to_rpn("8 / (3 + 1) * (3 - 2 + 4) ="))