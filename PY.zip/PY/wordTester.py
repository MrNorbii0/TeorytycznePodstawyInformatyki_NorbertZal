import csv
import random
import subprocess

subprocess.Popen(["python3", "hiszpanskieZnaki.py"])
file_path = input("Podaj ścieżkę pliku: ").strip().strip('"')
print(f"✅ Wczytana ścieżka: {file_path}")

hiszpanskie, polskie, wrong = [], [], []

with open(file_path, encoding="utf-8", newline="") as f:
    reader = csv.reader(f, delimiter=";")
    for row in reader:
        if len(row) >= 2:
            hiszpanskie.append(row[0].strip())
            polskie.append(row[1].strip())

# Budujemy listę indeksów i tasujemy, żeby każde pytanie padło dokładnie raz
indices = list(range(len(polskie)))
random.shuffle(indices)
counter = len(polskie)
print(counter)

for idx in indices:
    print(polskie[idx])
    while True:
        guess = input("").strip()
        if guess == hiszpanskie[idx]:
            counter -= 1
            print("✅ Słowo poprawne")
            print("Pozostałe słowa:", counter)
            break
        elif guess.lower() == "s":
            counter -= 1
            print(f"⏭️ Pomijam. Poprawna: {hiszpanskie[idx]}")
            print("Pozostałe słowa:", counter)
            wrong.append(hiszpanskie[idx])
            break
        else:
            print("❌ Słowo niepoprawne — spróbuj jeszcze raz")

print("\n❌ Słowa do nauki:")
for word in wrong:
    print("➜", word)
