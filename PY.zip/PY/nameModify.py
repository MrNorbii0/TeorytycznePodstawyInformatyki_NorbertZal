import os

def zmodyfikuj_nazwy_w_folderze(folder, tekst_dodany):
    for nazwa_pliku in os.listdir(folder):
        sciezka = os.path.join(folder, nazwa_pliku)

        if os.path.isfile(sciezka):
            nazwa, rozszerzenie = os.path.splitext(nazwa_pliku)
            nowa_nazwa = f"{nazwa}{tekst_dodany}{rozszerzenie}"
            nowa_sciezka = os.path.join(folder, nowa_nazwa)

            os.rename(sciezka, nowa_sciezka)
            print(f"Zmieniono nazwę: {nazwa_pliku} -> {nowa_nazwa}")

# Pobieranie danych od użytkownika
folder_docelowy = input("Podaj pełną ścieżkę do folderu z plikami: ").strip()
tekst_do_dodania = input("Podaj tekst, który ma zostać dopisany do nazw plików: ").strip()

# Uruchomienie funkcji
if os.path.isdir(folder_docelowy):
    zmodyfikuj_nazwy_w_folderze(folder_docelowy, tekst_do_dodania)
else:
    print("Podana ścieżka nie jest poprawnym folderem.")
