queue = []
next_ticket = 1

def add_customer():
    global next_ticket

    queue.append(next_ticket)
    print(f"Customer {next_ticket} added to queue")

    next_ticket += 1

def serve_customer():
    if len(queue) > 0:
        print(f"Customer {queue[0]} is being served")
        queue.pop(0)
    else:
        print(f"No customers in the queue!")

add_customer() 
add_customer() 
add_customer()

serve_customer()

add_customer() 
add_customer() 

serve_customer()
serve_customer()