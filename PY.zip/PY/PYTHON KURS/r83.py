def fileOpen(fileName):
        try:
            with open(fileName, 'r') as file:
                for line in file:
                    print(line.replace("\n", ""))

            return fileName
        except FileNotFoundError:
                print("Podany plik nie istnieje!")

file = input("Podaj nazwę pliku: ")

fileOpen(file + ".txt")