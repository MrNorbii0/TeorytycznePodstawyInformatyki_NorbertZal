names = ["Arkadiusz", "Wiola", "Antek"]

name = input("Podaj imię: ")
if name in names:
    print("Masz dostęp")
else:
    print("Nie masz dostępu")
