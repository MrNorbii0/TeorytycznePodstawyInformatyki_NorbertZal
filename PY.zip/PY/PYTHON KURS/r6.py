# + dodawanie
# - odejmowanie
# * mnożenie
# / dzielenie (przy dzieleniu wynik staje się floatem)

# () - kolejność wykonywania działań

# ** potęgowanie
# // dzielenie w 'dół' (zaokrąglenie wyniku w dół)
# % modulo