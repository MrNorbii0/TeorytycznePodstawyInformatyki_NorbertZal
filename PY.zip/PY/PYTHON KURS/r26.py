i = 0;
wynik = 0
while i < 3:
    number = int(input("Podaj liczbę: "))
    if number <= 0:
        print("Liczba powinna być dodatnia!")
        continue
    elif number % 2 != 0:
        print("Liczba powinna być parzysta:")
        continue
    else:
        i += 1
        wynik += number
        print("Aktualny wynik:", wynik)