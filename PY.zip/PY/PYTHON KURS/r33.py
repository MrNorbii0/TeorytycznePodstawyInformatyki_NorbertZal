#SŁOWNIK - KLUCZ: WARTOŚĆ
pokoje = {49: "Arkadiusz", 20: "Wiola"}
pokoje[18] = "Jan Kowalski"

a = {"imie": "Norbert", "nazwisko": "Żal"}
pokoje.update({25: "Bartek"})

del(pokoje[20])
pokoje.pop(49)
pokoje.popitem() #usuwa ostatni element