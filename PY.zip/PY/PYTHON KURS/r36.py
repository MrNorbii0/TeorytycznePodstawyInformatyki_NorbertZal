listaGosci1 = [
    ["Arkadiusz", 28, "mężczyzna"],
    ["Wiola", 22, "kobieta"],
    ["Kuba", 32, "mężczyzna"]
]

listaGosci2 = [ #to samo tylko krotki w środku
    ("Arkadiusz", 28, "mężczyzna"),
    ("Wiola", 22, "kobieta"),
    ("Kuba", 32, "mężczyzna")
]

for imie, wiek, plec in listaGosci1: #własne zmienne
    print(imie, wiek, plec)