"""
wynik = 0

for i in range(4):
    x = int(input("Podaj liczbę: "))
    wynik += x

print(wynik)
"""

for i in range(41):
    if(i % 5 == 0 and i % 7 != 0):
        print(i)