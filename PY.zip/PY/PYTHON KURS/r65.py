"""
def double(x):
    return x * 2
"""

test = lambda x: x*2
print(test(4))

myList = [2, 14, 22, 7, 6, 4, 5, 17]

filteredList = list(filter(lambda x: x % 2 == 0, myList)) #zajebiste
print(filteredList)

myListFiltered2 = [x for x in myList if(x % 2 == 0)] #inny sposób za pomocą listy wyrażeniowej
print(myListFiltered2)