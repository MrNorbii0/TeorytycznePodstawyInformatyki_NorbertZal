"""
shuffle - randomizuje liste
"""

import random

cardList = ["9", "9", "9", "9", "Jack", "Jack", "Queen"]

random.shuffle(cardList)
print(cardList)