#MIERZENIE WYDAJNOŚCI SKRYPTU - MODUŁ TIME
import time

def sum1(number):
    suma = 0

    for i in range(0, number+1) :
        suma += i

    return suma

def sum2(number):
    return sum([i for i in range(1, number+1)])

def sum3(number):
    return (1 + number)/2 * number

def finish_timer(start):
    end = time.perf_counter()
    return end - start

start = time.perf_counter()
print(sum1(2566))
print(finish_timer(start))

"""
start = time.perf_counter()
print(sum2(25665555))
end = time.perf_counter()
print(end - start)

start = time.perf_counter()
print(sum3(25665555))
end = time.perf_counter()
print(end - start)
"""