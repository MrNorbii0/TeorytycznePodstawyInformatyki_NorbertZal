numbersGenerator = (number for number in range(100, 400))

numbersToDivide = [
    number
    for number in numbersGenerator
    if number % 7 == 0 and number % 5 != 0
]

print(numbersToDivide)