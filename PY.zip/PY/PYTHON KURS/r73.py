import math, random

isChest = ["YES", "NO"]
chestColor = ["zielony", "pomarańczowy", "fioletowy", "legendarny"]
sumGold = 0
gold = 0
moves = 0

while moves < 5:
    input("Aby wylosować naciśniej enter: ")
    moves += 1

    isChestCheck = random.choices(isChest, [60, 40])

    if isChestCheck[0] == 'YES':
        chestColorPicked = random.choices(chestColor, [75, 20, 4, 1])
        if chestColorPicked[0] == 'zielony':
            gold = 1000
        elif chestColorPicked[0] == 'pomarańczowy':
            gold = 4000
        elif chestColorPicked[0] == 'fioletowy':
            gold = 9000
        else:
            gold = 14000
        sumGold += gold
        print("Skrzynka! \nKolor:", chestColorPicked[0], "\nZdobywasz:", gold, "złota\nMasz łącznie:", sumGold, "złota")
    
    else:
        print("Tym razem pech")