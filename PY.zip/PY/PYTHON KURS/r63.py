#OBIEKTY IMMUTABLE (niezmienne) I MUTABLE (zmienne)

a = 4
print(a.bit_length())

listSample = [1, 4, 512, 24]
listSample2 = listSample #w zmiennych mutable po znaku "=" następuje zmiana miejsca wskazywania na nowy adress, na inny obiekt, teraz te listy są ze spobą powiązane

listSample2.append(465)
print(listSample)