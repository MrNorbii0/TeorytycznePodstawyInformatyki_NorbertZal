zbior1 = {1, 4, 5, 20}
zbior2 = {4, 1, 10, 15}
lista = [3, 10, -2, 5]

set(lista) #zamiana listy w zbiór, zostaje zmieniona kolejność, świetne do usuwanie duplikatów

print(zbior1&zbior2) #elementy wspólne zbioru
print(zbior1|zbior2) #połączenie elementów zbioru i one się posortują, elementy na pewno są unikalne (brak powtorzen)
print(zbior1-zbior2) #wszystkie elementy zbioru1 ktorych nie ma w zbiore2
print(zbior1^zbior2) #wykluczenie wspólnych wartości

zbior1.discard(1) #lepsze niż remove

print(zbior1.issubset(zbior2)) #sprawdzanie czy zbior1 jest podzbiorem zbioru2