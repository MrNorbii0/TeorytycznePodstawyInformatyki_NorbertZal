import figury

print(figury.pole_kola(10))