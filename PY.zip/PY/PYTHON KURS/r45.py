#FUNKCJE

def welcome(name):
    print("Witaj", name)

welcome("Arek")

names = ["Arek", "Wiola", "Michał"]

for name in names:
    welcome(name)