"""
def any_even(list):
    for i in list:
        if i % 2 == 0:
            print("Zawiera")
            return True
    print("Nie zawiera")
    return False
    
myList = [1, 3, 5, 6, 7]
myList2 = [1, 3, 5, 7, 9]

any_even(myList2)
"""

#funkcja any() sprawdza czy jakakolwiek wartość to TRUE
#funckja all() sprawdza czy wszystkie wartości to TRUE

myList = [1, 3, 5, 6, 7]
myList2 = [1, 3, 5, 7, 9]

# test = [i % 2 == 0 for i in myList]
# test2 = [i % 2 == 0 for i in myList2]

# print(any(test), any(test2))

def any_even(list):
    output = [i % 2 == 0 for i in list]
    if any(output) == True:
        print("Zawiera")
        return True
    
    print("Nie zawiera")
    return False

any_even(myList)
any_even(myList2)