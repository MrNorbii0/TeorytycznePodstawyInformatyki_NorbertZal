"""
Przydatne funkcje dot. list:
    len() - długość listy
    .append - dodać
    .extend - rozszerzyć
    .insert(index, co wstawiamy) - wstawć
    .index - indeks danego elementu
    sort() - posortować
    max() - wartość max
    min() - wartość min
    .count - ile razy coś wystąpi
    .pop - usuć ostatni element
    .remove - usuń pierwsze wystąpienie
    .clear - wyczyść listę
    .reverse - zamień kolejność
"""

lista1 = [1, 2, 3, 4, 5]
lista2 = ["Arkadiusz", "Wiola", "Antek"]

print(len(lista2))
lista1.append(4)
lista1.extend([7, 8, 9])
lista2.insert(0, "Kuba")
print(lista2.index("Arkadiusz"))
lista1.sort(reverse=True) #sortowanie malejące
max(lista1)
min(lista1)
print(lista1.count(1))
lista1.pop()
lista1.remove(1) #usuwa PIERWSZY ELEMENT