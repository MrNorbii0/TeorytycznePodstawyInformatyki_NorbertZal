# a = int(input("Podaj a: "))
# b = int(input("Podaj b: "))

# if (a > b):
#     print("A większe od B")
# elif (b > a):
#     print("B większe od A")
# else:
#     print("Równe jest i huj")

#zadanie
number = int(input("Podaj liczbę: "))

if number > 0:
    print(number)
elif number < 0:
    number = abs(number)
    print(number)
else:
    print(number)