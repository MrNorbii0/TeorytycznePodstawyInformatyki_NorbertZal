def count(*numbers):
    return sum(numbers)

print(count(2,4,1,2,4,5, 10))