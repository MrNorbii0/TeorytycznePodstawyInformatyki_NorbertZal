imiona = ["Norbert", "Wiola", "Kuba", "Adrian"]
liczby = [1, 2, 5, 10]
mieszana = [1, "Norbert", True]

for i in imiona:
    print(i)

imiona[-1] = "Kazik"
print(imiona[-1]) #ostatni element z listy ZAJEBISTE TO JEST