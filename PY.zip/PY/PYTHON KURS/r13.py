import math
# from math import sqrt

pierwiastek = math.sqrt(4)
print(pierwiastek)