"""
random() - przedział [0, 1)

uniform(2.5, 10.0) - przedział [2.5, 10)
randrange(10) - z puli (0, 9)
ranrange(0, 15, 2) - z puli co drugie

randint(0, 4) - przedział [0, 4]
"""

import random
from collections import Counter #do liczenia fajne

# x = 0
# while x < 100:
#     x = x + 1
#     print(round(random.uniform(0, 100)))

def will_hit(chanceToHit):
    isHitChance = random.uniform(0, 100)

    if(isHitChance < chanceToHit):
        return "hit"
    else:
        return "not hit"

listHit = []

x = 0
while x < 100:
    x = x + 1
    listHit.append(will_hit(50))

print(listHit.count("hit"))
dictHit = Counter(listHit)
print(dictHit)

print(random.randint(0, 10))