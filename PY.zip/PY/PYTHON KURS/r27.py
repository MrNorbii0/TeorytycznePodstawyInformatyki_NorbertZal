numberToFound = 23
guessNumber = 0

while guessNumber != numberToFound:
    guessNumber = int(input("Podaj liczbę: "))
    if (guessNumber >  numberToFound):
        print("Podana liczbę jest za duża!")
    else:
        print("Podana liczba jest za mała!")

print("Zgadłeś!")