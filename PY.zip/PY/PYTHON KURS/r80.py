with open("nazwaPliku.txt", 'a') as file:
    print(file.tell())
    file.write("\nLalalaal")