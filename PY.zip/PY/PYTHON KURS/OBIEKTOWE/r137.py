from random import randint
from r136 import RocketBoard

board = RocketBoard(3)

print(board.rockets[0].altitude)
# print(board[0])

print(board[1])