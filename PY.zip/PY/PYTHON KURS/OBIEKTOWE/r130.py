class User:
    age = 0 #domyślna wartość pola

seba = User() #stworzenie obiektu seba
mirek = User()

mirek.age = 24

print(seba.age)
print(mirek.age)
