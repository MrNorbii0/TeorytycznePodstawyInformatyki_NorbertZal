from random import randint

class Rocket:
    def __init__(self, speed):
        self.altitude = 0
        self.speed = speed

    def moveUp(self):
        self.altitude += self.speed

    def __str__(self):
        return "Aktualna wysokość rakiety: " + str(self.altitude)
    
class RocketBoard:
    def __init__(self, amountOfRockets=5):
        self.rockets = [Rocket(randint(0, 10)) for _ in range(amountOfRockets)]

        for _ in range(10):
            rocketIndexToMove = randint(0, len(self.rockets) - 1)
            self.rockets[rocketIndexToMove].moveUp()

        for rocket in self.rockets:
            # print(rocket.altitude)
            print(rocket)

    def __getitem__(self, key): #metoda służy do 'indeksowania' obiektów
        return self.rockets[key]
    
    def __setitem__(self, key, value): #metoda służy do umożliwniea przypisywania wartości do pól
        self.rockets[key].altitude = value