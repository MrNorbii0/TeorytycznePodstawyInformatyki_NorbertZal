class User:
    age = 0
    def print_age(self, message):
        print("wiek:", self.age, message)

seba = User()
seba.age = 16
seba.print_age("tekst")

userList = [User(), User()]
userList[0].age = 5
userList[0].print_age("blabla")