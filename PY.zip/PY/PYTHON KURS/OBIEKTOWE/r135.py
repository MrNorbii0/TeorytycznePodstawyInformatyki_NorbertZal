from random import randint

class Rocket:
    def __init__(self, speed): #metoda dunder, czyli z dwoma podkreślnikami
        self.altitude = 0
        self.speed = speed

    def moveUp(self):
        self.altitude += self.speed

    def __str__(self): #kiedy chcemy wypisać sam obiekt jako string, to zamiast adresu pojawi się to co zwrócimy
        return "Aktualna wysokość rakiety: " + str(self.altitude)

rockets = [Rocket(randint(0, 10)) for _ in range(5)]
print(rockets)

for _ in range(10):
    rocketIndexToMove = randint(0, 4)
    rockets[rocketIndexToMove].moveUp()

for rocket in rockets:
    # print(rocket.altitude)
    print(rocket)