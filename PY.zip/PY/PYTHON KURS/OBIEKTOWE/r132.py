class User:
    def __init__(self, age, name): #konstruktor
        self.age = age #tworzenie nowego atrybutu, BARDZO WAŻNE SELF
        self.name = name

user1 = User(30, "Arek")