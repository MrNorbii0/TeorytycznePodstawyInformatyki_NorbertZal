wynik = 0
i = 0

while i < 4:
    x = int(input("Podaj liczbę: "))
    wynik += x
    i += 1


print("Wynik:", wynik)