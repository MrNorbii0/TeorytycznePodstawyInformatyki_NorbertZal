with open("nazwaPliku.txt", "w") as file: #teraz plik zostanie automatycznie zamknięty, nawet jeśli wystąpią errory
    print(0/0)
    file.write("Sample")