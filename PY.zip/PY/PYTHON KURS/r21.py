wartosc = int(input())

if wartosc > 1 and wartosc < 10:
    print(wartosc)

if wartosc == 5 or wartosc == 2:
    print(wartosc)

# i - and
# lub - or
# nie - not