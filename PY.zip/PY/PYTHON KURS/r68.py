# #tworzymy liste
# colors = ["red", "green", "blue"]
 
# # wybieramy elementy z krotki i je wyświetlamy:
# for i, color in enumerate(colors):
#     print(i, color)

tasks = ["clean the kitchen", "do laundry", "pay bills"]

for i, task in enumerate(tasks):
    print(i+1, task.capitalize())