imie = "norbert"
print(imie.capitalize()) #powiększenie pierwszej litery na dużą, pozostałe zmniejsza

imie = imie.capitalize() #imie zostało nadpisane