a,b,c = 1, 5, 10 # a = 1, b = 5, c = 10

q,w,e = 3, "lala", True