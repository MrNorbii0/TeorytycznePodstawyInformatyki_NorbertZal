def area(a, b):
    return a*b #to nam zwraca wartość

area(5,2)

poleA = area(1, 2)
poleB = area(2, 10)

print(poleA)
print(poleB)

def division(a, b):
    if b == 0:
        return
    
    return a / b

print(division(5, 0))

if (division(5, 0)):
    print("Git")
else:
    print("Dupa")