def area(a, b):
    print("Pole wynosi:", a*b)

area(5,2)