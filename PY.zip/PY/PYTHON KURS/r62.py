c = 1 #zmienna globalna

def add():
    global c #operujemy na globalnej zmiennej
    c = c + 5 #zmienna lokalna
    return c

print(add())