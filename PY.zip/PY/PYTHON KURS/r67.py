John = {
    'name': "John Doe",
    'age': 28,
    'skills': ["Python", "Javascript", "C++"]
}

Jane = {
    'name': "Jane Kowalska",
    'age': 22,
    'skills': ["Javascript", "C++"]
}

# test = all(skill in Jane['skills'] for skill in ["Python", "Javascript"])
# print(test)

def has_requierd_skills(dict, arg = "skills"):
    if all(skill in dict[arg] for skill in ["Python", "Javascript"]):
        print("Pracownik ma odpowiednie umiejętności")
        return True
    
    print("Pracownik nie ma odpowiednich umiejętności")
    return False

has_requierd_skills(John)
has_requierd_skills(Jane)
