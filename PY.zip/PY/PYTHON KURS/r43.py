#WYRAŻENIA ZBIORU

names = {"arkadiusz", "Wioletta", "karol", "bartek"}

names = {
    name.capitalize()
    for name in names
}

print(names)

deletedNames = {
    name.remove
    for name in names
    if name.startswith == "B"
}

print(deletedNames)