potegiGenerator = (element**2
                   for element in range(100)
                   ) #wyrażenie generujące, nie wczytuje wszystkich danych do pamięci od razu, nie są one zapisywane, TO NIE JEST LISTA

print(sum(potegiGenerator))