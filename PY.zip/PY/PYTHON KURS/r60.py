#ARGUMENT WIELOWARTOŚCIOWY

import time

def function_performance(func, *arg, how_many_times = 1): #dzięki gwiazdce można przesyłać kilka argumentów do jednego argumentu
    timeSum = 0

    for i in range(0, how_many_times):
        start = time.perf_counter()
        func(*arg) #wszędzie ją trzeba dodać, jedna gwiazdka to argumenty nienazwane i się zrobi krotka - odwołanie: arg[0] | dwie gwiazdki się zrobi słownik - odwołanie: arg.get("argument")
        end = time.perf_counter()
        timeSum = timeSum + (end-start)

    return end - start

listContainer = [i for i in range(0, 101)]
setContainer = {i for i in range(0, 101)}

def check(number, container):
    if number in container:
        print("Znajduje się")
        return True
    else:
        print("Huja nie ma")
        return False
    
function_performance(check, 200, setContainer, how_many_times = 2)
#PO GWIAZDCE TRZEBA DAĆ ARGUMENT NAZWANY, albo dać argument z gwiazdka na koniec