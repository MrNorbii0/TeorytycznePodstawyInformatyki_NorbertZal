try:
    with open("tekst.txt", 'r', encoding="UTF-8") as file:
        kotes = file.read().lower()
        kotesAmount = kotes.count("kot")
        print(f"Ilość kotów to {kotesAmount}")

except FileNotFoundError:
    print("Brak pliku!")
except PermissionError:
    print("Brak dostępu do pliku!")