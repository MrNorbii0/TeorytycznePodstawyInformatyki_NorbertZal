# a = int(input("Podaj dowolną wartość: ")) #bez parsowania to bedzie zawsze ciag znaków
# print(a)

# b = 2

# print (a + b)
# print("Wynik dodawania to: " + str(a + b)) #parsowanie na stringa
# print("Wynik dodawania", a, "do", b, "to:", a + b) #sposób bez parsowania


#zadanie
name = input("Podaj swoje imię: ")
age = int(input("Podaj swój wiek: "))
color = input("Podaj swój ulubiony kolor: ")

print("Hej", name, ", twój ulubiony kolor to", color)
print("Masz", age, "lat")
print("Za rok będziesz miał", age + 1, "lat")