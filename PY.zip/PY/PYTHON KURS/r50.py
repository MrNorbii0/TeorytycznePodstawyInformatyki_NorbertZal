def plusNumbers(numbers):
    numbersList = [
        element
        for element in numbers
        if element > 0
    ]
    return numbersList

liczby = [-2, -3 , 4, -1, 5]

print(plusNumbers(liczby))