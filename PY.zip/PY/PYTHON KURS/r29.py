imiona = ["Norbert", "Wiola", "Kuba", "Adrian"]
liczby = [1, 2, 5, 10]

if "Norbert" in imiona:
    print("Siema Norbii")

if 3 not in liczby:
    print("Nie ma takiej liczby i elo")

print(imiona + liczby) #łączenie liczb