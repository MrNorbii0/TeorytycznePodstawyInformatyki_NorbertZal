import math, random

# pick = random.choice(numbers)
# print(pick)
# numbers.remove(pick)
# print(numbers)

def choose_random_numbers(amount, totalAmount):
    numbers = [numbers for numbers in range(1, totalAmount+1)]

    pickList = []
    for i in range(0 , amount):
        pick = random.choice(numbers)
        pickList.append(pick)
        numbers.remove(pick)
        i += 1

    print("Wylosowane liczby:", pickList)
    return pickList

choose_random_numbers(6, 50)

numbers = [numbers for numbers in range(1, 50)]
print(random.sample(numbers, 6)) #zajesbite, sample losuje bez powtórzen