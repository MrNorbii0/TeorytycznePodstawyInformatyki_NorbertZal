"""
choice - zwraca losowy element
choices - zwraca listę elementó i ma większe możliwości
"""

import random

moveList = ["t1", "t2", "t3"]
event = ["smierc", 'wygrana', 'przegrana']
nagroda = ['zielona', 'zolta', 'czerwona']

print(random.choice(moveList))

from collections import Counter
print(Counter(random.choices(nagroda, [80, 15, 5], k = 100))) #zajebiste, co ma wylosować z listy i ustawione prawdopodobieństwo