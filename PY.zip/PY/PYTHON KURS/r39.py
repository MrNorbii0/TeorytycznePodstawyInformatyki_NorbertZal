definitions = {
    "Burza": ("takie z piorunami"),
    "Pies": ("czworonogi przyjaciel")
}

def showDefs():
    for word in definitions:
        print(word, "znaczy:", definitions[word])

def addDefs(newDefinition, meaning):
    definitions[newDefinition] = meaning
    print("Definicja dodana pomyślnie")

def findDef(definitionToFind):
    if definitionToFind in definitions:
        print(definitionToFind, "oznacza:", definitions[definitionToFind])
    else:
        print("Brak definicji")

def delDef(definitionToDelete):
    if definitionToDelete in definitions:
        del(definitions[definitionToDelete])
        print("Definicja została usunięta")
    else:
        print("Brak definicji")

print("1 - Dodaj definicję")
print("2 - Znajdź definicję")
print("3 - Usuń definicję")
print("4 - Wyświetl słownik")
print("5 - Zakończ")

while(True):
    action = int(input("Co chcesz zrobić? "))

    if action == 1:
        newDef = input("Podaj słowo do zdefiniowania: ")
        mean = input("Podaj definicję słowa")
        addDefs(newDef, mean)
    elif action == 2:
        defFind = input("Podaj szukane słowo")
        findDef(defFind)
    elif action == 3:
        defDel = input("Podaj słowo do usunięcia")
        delDef(defDel)
    elif action == 4:
        showDefs()
    else:
        break