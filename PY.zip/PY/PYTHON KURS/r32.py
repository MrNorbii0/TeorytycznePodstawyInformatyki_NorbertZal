krotka = 1, 42, 12, -4

#z krotki korzystamy zawsze, jak nie potrzebujemy zmieniać wartości