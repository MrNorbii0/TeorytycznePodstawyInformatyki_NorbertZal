"""
Operacje na plikach:
    - otwieranie
    - pisanie/czytanie
    - zamykanie

Sposoby otwierania plików:
    - r --> READ
    - w --> WRITE (jeśli plik istanił to go zamieni na nowy, jak nie to stworzy nowy)
    - a --> APPEND
"""

file = open("nazwaPliku.txt", "w") #handle
file.write("Sample")

file.close()