#ARGUMENTY KLUCZOWE I POZYCYJNE
#kluczowy - w postaci: klucz - wartość (domyślny)
#pozycyjny - liczy się kolejność przy wywołaniu

def greet(name, message, separator=" "):
    print(message, name, sep=separator)

# greet(message="Witojcie", name="Arek")
greet("Arek", "Witojcie", "\n")