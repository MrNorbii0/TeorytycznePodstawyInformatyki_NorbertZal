imie = "Norbert"
nazwisko = "Zal"

print (imie + " " + nazwisko)

# dlugiString = "To jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczymTo jest tek o niczym"

imie = "Wiola"
print(imie[-1]) #ostatni element stringa zawsze
print(imie[1:]) #wszystkie elementy bez pierwszego
print(imie[:-1]) #wszystkie elementy bez ostatniego
print(imie[1:3]) #od 1 do 3 (bez 3)