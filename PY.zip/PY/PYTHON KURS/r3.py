wiek = 28
print(wiek)

print(0.4+0.3)