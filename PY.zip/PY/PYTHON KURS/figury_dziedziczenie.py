class Square:
    def __init__(self, x):
        self.x = x

    def pole(self):
        return pow(self.x, 2)
    
class Rectangle(Square):
    def __init__(self, x, y):
        super().__init__(x)
        self.y = y

    def pole(self):
        return self.x * self.y

class Cube(Rectangle):
    def __init__(self, x, y, z):
        super().__init__(x, y)
        self.z = z

    def pole(self):
        return 6 * self.x * self.y
    
    def objetosc(self):
        return self.x * self.y * self.z
    
kwadrat = Square(5)
print(kwadrat.pole())

prostokat = Rectangle(2, 5)
print(prostokat.pole())

kostka = Cube(2, 4, 5)
print(kostka.pole())
print(kostka.objetosc())

