try:
    file = open("nazwaPliku.txt", "w") #handle
    print(0/0)
    file.write("Sample")

finally:
    file.close()
    print("Plik zamknięty")

#po finally wykona się coś ZAWSZE pomimo błędy w sekcji try