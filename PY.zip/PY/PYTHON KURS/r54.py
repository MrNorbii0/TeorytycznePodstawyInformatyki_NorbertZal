def sum1(number):
    suma = 0

    for i in range(0, number+1) :
        suma += i

    return suma

def sum2(number):
    return sum([i for i in range(1, number+1)])

def sum3(number):
    return (1 + number)/2 * number

print(sum3(5))