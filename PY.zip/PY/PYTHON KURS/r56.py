#PRZESYŁANIE FUNKCJI JAKO ZMIENNEJ
import time

def sum1(number):
    suma = 0

    for i in range(0, number+1) :
        suma += i

    return suma

# def finish_timer(start):
#     end = time.perf_counter()
#     return end - start

def function_performance(func, arg):
    start = time.perf_counter()
    func(arg)
    end = time.perf_counter()
    return end - start

print(sum1(5), function_performance(sum1, 5))