"""
Mnogie tryby otwierania plików:
    - r+ - do czytania i pisania
    - w+ - do pisania i czytania, jeśli plik nie istniał to go stworzy
    - a+ - wieczny tryb dopisywania i czytania, wskaźnik jest zawsze na końcu, jeśli plik nie istniał to go stworzy
"""