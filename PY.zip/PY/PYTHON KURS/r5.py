a = 5 #int
b = 4.3 #float
zdanie = "Norbert to fajne imie" #string
czyDuzy = True #bool
#python jest case sensitive!!