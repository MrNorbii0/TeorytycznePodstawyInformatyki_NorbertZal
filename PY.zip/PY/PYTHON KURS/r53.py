import figury
from enum import Enum, IntEnum

"""
# Menu_Figury = IntEnum('Menu_Figury', 'Kwadrat, Prostokąt, Koło, Trójkąt, Trapez')
Menu_Figury = IntEnum('Menu_Figury', ['Kwadrat', 'Prostokąt', 'Koło', 'Trójkąt', 'Trapez']) #alternatywnie można przesłać liste, słownik też można

wybor = int(input("Podaj figurę: "))

if wybor == Menu_Figury.Kwadrat: #jesli nie korzystam z IntEnum to musze tutaj dopisać .value
    a = float(input("Podaj bok: "))
    print("Pole kwadratu:", figury.pole_kwadratu(a))

"""

Menu_Colors = IntEnum('Menu_Colors', "Red, Green, Blue, Yellow")

choice = int(input("Jaki chcesz kolor: "))

if choice == Menu_Colors.Red:
    print("Czerwony")
elif choice == Menu_Colors.Green:
    print("Zielony")
elif choice == Menu_Colors.Blue:
    print("Niebieski")
elif choice == Menu_Colors.Yellow:
    print("Zółty")
