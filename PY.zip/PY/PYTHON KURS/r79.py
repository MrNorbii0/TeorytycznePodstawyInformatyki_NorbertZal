with open("nazwaPliku.txt", "r", encoding="UTF-8") as file:
    zawartosc = file.readline() #pierwsza linijka
    print(zawartosc)
    print(file.tell())
    file.seek(0)
    print(file.tell())