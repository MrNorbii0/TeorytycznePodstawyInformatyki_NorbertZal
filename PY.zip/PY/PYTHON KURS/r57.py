#DOMYŚLNE ARGUMENTY

# def increment(x, amount = 1):
#     return x + amount

# print(increment(2))
import time

def sum1(number):
    suma = 0

    for i in range(0, number+1) :
        suma += i

    return suma

def function_performance(func, arg, how_many_times = 1):
    timeSum = 0

    for i in range(0, how_many_times):
        start = time.perf_counter()
        func(arg)
        end = time.perf_counter()
        timeSum = timeSum + (end-start)

    return end - start

print(sum1(5), function_performance(sum1, 5, 3))