#WYRAŻENIE SŁOWNIKOWE

names = {"Arkadiusz", "Wioletta", "Karol"}
numbers = [1, 2, 3, 4, 5]
celcius = {'t1': -20, 't2': -15, 't3': 5}

namesLength = {
    name : len(name)
    for name in names
    if name.startswith("A")
}

print(namesLength)

multiplicationNumbers = {
    number : number*number
    for number in numbers
}

print(multiplicationNumbers)

farenheit = {
    key : value * 1.8 + 32
    for key, value in celcius.items()
    if value > -5
}

print(farenheit)