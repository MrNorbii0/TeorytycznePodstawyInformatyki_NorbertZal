with open("nazwaPliku.txt", "r", encoding="UTF-8") as file:
    zawartosc = file.read()
    # zawartosc = file.read().splitlines() #zwraca liste kolejnych linijek tekstu, nie zachowuje \n
    zawartosc = file.readline() #pierwsza linijka
    zawartosc = file.readlines() #wszystkie linijki jako lista i zachowuje \n
    print(zawartosc)

with open("nazwaPliku.txt", "r", encoding="UTF-8") as file2:
    for line in file2:
        print(line)