import copy

def evil_function(listToBeDestroyed):
    print(id(listToBeDestroyed))
    listToBeDestroyed.clear()

myList = [1, 4, 2, 1, 52, 3]
myList2 = [[1, 4], [2, 1], [52, 3]]

print(id(myList))
print(id(myList2))

evil_function(myList.copy()) #kopia płytka - to stosujemy na obiekty immutable (int, float, string itp.)
evil_function(list(myList)) #inny sposób na kopiowanie
evil_function(myList[:]) #inny sposób na kopiowanie

evil_function(copy.deepcopy(myList2)) #kopia głębkoka - to stosujemy na obiekty mutable (listy, zbiory itp.)