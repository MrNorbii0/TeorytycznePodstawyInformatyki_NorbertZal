VAT = 0.23

cenaNetooJava = 10
cenaNetooAjax = 20

cenaBruttoJava = cenaNetooJava * (1 + VAT)
cenaBruttoAjax = cenaNetooAjax * (1 + VAT)

print(cenaBruttoJava)