#TYPY ZAGNIEŻDŻONE

listaGosci1 = [
    ["Arkadiusz", 28, "mężczyzna"],
    ["Wiola", 22, "kobieta"],
    ["Kuba", 32, "mężczyzna"]
]

listaGosci2 = [ #to samo tylko krotki w środku
    ("Arkadiusz", 28, "mężczyzna"),
    ("Wiola", 22, "kobieta"),
    ("Kuba", 32, "mężczyzna")
]

listaGosci1[0][1] = 29
print(listaGosci1[0][1])

listaGosci1.append(["Karol", 20, "mężczyzna"])

print(listaGosci1)