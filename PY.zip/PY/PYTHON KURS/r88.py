import json
import pprint

film = {
    "title" : "Ale ja nie będę tego robił!",
    "release_year" : 1969,
    "won_oscar" : True,
    "actors": ("Arkadiusz Włodarczyk", "Wiolleta Włodarczyk"),
    "budget" : None,
    "credits" : {
            "director" : "Arkadiusz Włodarczyk",
            "writer" : "Alan Burger",
            "animator" : "Anime Animatrix"
            }
}

encodedFilm = json.dumps(film, ensure_ascii=False, indent=4, sort_keys=True) #indent - wcięcia | sort_keys=True - alfabetyczne klucze
print(encodedFilm)

encodedFilm2 = json.dumps(film, ensure_ascii=False)
pprint.pprint(encodedFilm2) #od razu ładnie wypisuje format JSON

with open("sampleJson.json", 'w', encoding="UTF-8") as file:

    json.dump(film, file, ensure_ascii=False)