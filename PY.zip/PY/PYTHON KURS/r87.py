import json

with open("sampleJson.json", 'r', encoding="UTF-8") as file:
    encodedFilm = json.load(file) #json loads jak mamy Json w zmiennej jakby

    print(encodedFilm)