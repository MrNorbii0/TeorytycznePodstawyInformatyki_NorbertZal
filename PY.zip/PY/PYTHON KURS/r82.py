container = []

with open("imionanazwiska.txt", "r", encoding="UTF-8") as file:

    for line in file:
        container.append(tuple(line.replace("\n", "").split()))

with open("namesList.txt", "w", encoding="UTF-8") as names:
    
    for item in container:
        names.write(item[0] + "\n")

with open("surnamesList.txt", "w", encoding="UTF-8") as surNames:

    for item in container:
        try:
            surNames.write(item[1] + "\n")
        except IndexError:
            surNames.write("Brak nazwiska" + "\n")