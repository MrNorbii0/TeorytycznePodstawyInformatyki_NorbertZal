listContainer = [i for i in range(0, 101)]
setContainer = {i for i in range(0, 101)}

def check(number, container):
    if number in container:
        print("Znajduje się")
        return True
    else:
        print("Huja nie ma")
        return False

check(100, setContainer)