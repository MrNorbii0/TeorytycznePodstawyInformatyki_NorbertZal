liczba = 0

while liczba <= 5:
    print(liczba)
    liczba += 1

#zadanie
number = 100

while number >= 0:
    print(number)
    number -= 1