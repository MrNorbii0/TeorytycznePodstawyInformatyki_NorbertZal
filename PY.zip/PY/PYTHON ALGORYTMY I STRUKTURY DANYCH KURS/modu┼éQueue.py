import queue

q = queue.Queue() #FIFO - kolejka

for i in range(11, 16):
    q.put(i)

print(q.qsize())

while q.qsize() > 0:
    print(q.get(), "i zostało jeszcze", q.qsize(), "elementów")


lifo = queue.LifoQueue() #LIFO - stos

for i in range(11, 16):
    lifo.put(i)

print(lifo.qsize())

while lifo.qsize() > 0:
    print(lifo.get())

priority_q = queue.PriorityQueue() #FIFO - kolejka, ale z priorytetami

priority_q.put((1, "Najważniejsze"))
priority_q.put((3, "Nie ważne"))
priority_q.put((2, "Średnio ważne"))
priority_q.put((2, "Średnio ważne - jeszcze raz"))

while priority_q.qsize() > 0:
    print(priority_q.get())


#ZADANIE

my_path='/home/boss/data/projects/bakery/prices.csv'
pathElements = my_path.split('/')
pathElements.remove("")
print(pathElements)

pathLifo = queue.LifoQueue()

for i in pathElements:
    pathLifo.put(i)

while pathLifo.qsize() > 0:
    print(pathLifo.get())
