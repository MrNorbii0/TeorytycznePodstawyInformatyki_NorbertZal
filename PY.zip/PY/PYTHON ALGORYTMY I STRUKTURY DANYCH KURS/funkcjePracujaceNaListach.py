l = [1,2,3] #lista jest przykładem iteratora

i = l.__iter__()
print(i)

print(i.__next__()) #1
print(i.__next__()) #2
print(i.__next__()) #3
#iterator przechodzi tyle razy, ile wywołamy funkcje

for n in l:
    print(n)

animals = map(lambda x: x.upper(), ['cat', 'dog', 'cow']) #mapowanie zwraca iterator
print(animals.__next__())

animals2 = list(map(lambda x: x.upper(), ['cat', 'dog', 'cow'])) #konwersja do listy
print(animals2)

animals3 = list(filter(lambda x: "o" in x, ['cat', 'dog', 'cow'])) #wykonuje zadaną funkcje na każdej wartości i zwraca True i False (zajebiste)
print(animals3)

from functools import reduce

numbers = [11, 22, 33, 1]
max_number = reduce(lambda x,y: x if x > y else y, numbers)
print(max_number)

ids = ['id1', 'id2', 'id30', 'id3', 'id22', 'id100']
print(sorted(ids)) #to posortuje alfabetycznie tylko 

print(sorted(ids, key=lambda x: int(x[2:]))) #pomijamy pierwsze dwa znaki, konwertujemy do inta i sortujemy po id

from heapq import nsmallest, nlargest

print(nlargest(3, ids, key=lambda x: int(x[2:]))) #ile wartości ma zwrócic, z czego je pobrac i na co patrzeć | zwraca największe wartości
print(nsmallest(3, ids, key=lambda x: int(x[2:]))) #ile wartości ma zwrócic, z czego je pobrac i na co patrzeć | zwraca najmniejsze wartości

####ZADANIE

lista = [1, 45, 672, 7265, 16]
# def stringConvert(listToConvert):
#     convList = []
#     for l in listToConvert:
#         convList.append(str(l))
#     return convList

sorted_list = sorted(lista, key=lambda x: x % 10)
print(sorted_list)

test = 233345435435
print(test % 10) #odwołanie do ostantiej liczby wtf

codes = ['JPID', 'JJJPPP', 'XXX', 'JDU']
print(type(len(codes[0])))
theLongest = reduce(lambda x, y: x if len(x) > len(y) else y, codes)
print(theLongest)

capitals =['Rome', 'Paris', 'Madrid']
cities = ['Rome', 'Napoli', 'Rimini', 'Paris', 'Barcelona', 'Madrid', 'Marceille']
notCapitals = list(filter(lambda x: x not in capitals, cities))
print(notCapitals)