import pandas as pd

dataFrame = pd.DataFrame(
    [
        [1, 'Matematyka', 3, False],
        [2, 'Geometria', 1, False],
        [3, 'Przyroda', 4, True]
    ]
)

# print(dataFrame)

# dataFrame.columns = ['ID', 'Name', 'Amount', 'Promo']

# print(dataFrame)
# print(dataFrame[['Name', 'Amount']])

# print(dataFrame.iloc[1:, 1]) #1: od 1 elementu (0 pominęliśmy) do końca, pierwszy wiersz

# print(dataFrame[dataFrame.Amount > 1]) #wyświetlamy to co chcemy


#ZADANIE
uni = pd.read_csv('school_and_country_table.csv', encoding='UTF-8')
# print(uni.head())
# print(uni[["country"]])
print(uni[(uni.country == 'Poland') | (uni.country == 'China')])


