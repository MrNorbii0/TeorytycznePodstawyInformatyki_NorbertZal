# ben = {
#     "name": "Ben",
#     "phone": "123456789",
#     "email": "ben@example.com"
# }

# jan = {
#     "name": "Jan",
#     "phone": "123456789",
#     "email": "jan@example.com"
# }

# ann = {
#     "name": "Ann",
#     "phone": "123456789",
#     "email": "ann@example.com"
# }

# contact_list = [ben, jan, ann]
# print(contact_list)

# all_emails = ''
# for c in contact_list:
#     all_emails += c['email'] + ";"

# print(all_emails)

# ######

# contact_dict = {}
# for c in contact_list:
#     contact_dict[c["name"]] = c

# print(contact_dict['Ann']["email"])

# #Listę najlepiej używać, kiedy w programie będziemy operaować na wszystkich wartościach.
# #Słownik najlepiej używać, kiedy w programie będziechmy chcieli się odwołać do konkretnych wartości.


##ZADANIE

lecture1 = {
    "hour" : "9:00",
    "topic" : "Mikrobiologia",
    "lecturer" : "prof. Wirus"
}

lecture2 = {
    "hour" : "12:00",
    "topic" : "Chemia",
    "lecturer" : "dr. Kolba"
}

lecture3 = {
    "hour" : "14:00",
    "topic" : "Etyka",
    "lecturer" : "dr. Olej"
}

lecture_list = [lecture1, lecture2, lecture3]

lecture_dict = {}
for l in lecture_list:
    lecture_dict[l["topic"]] = l

# print(lecture_dict)

for index in lecture_dict:
    print(lecture_dict[index]['hour'], lecture_dict[index]['topic'])

for h, t in lecture_dict.items():
    print(f"{t['topic']} o godzinie {t['hour']}")

# print(lecture_dict["Mikrobiologia"]["hour"], lecture_dict["Mikrobiologia"]["topic"])
