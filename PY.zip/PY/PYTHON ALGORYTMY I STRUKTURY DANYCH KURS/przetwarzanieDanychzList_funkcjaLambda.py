# myList = list(range(10))
# print(myList)

# # def square(x):
# #     powed_list = []
# #     for i in x:
# #         powed = pow(i, 2)
# #         print(powed)
# #         powed_list.append(powed)
# #     return powed_list

# # print(square(myList))

# def square(x):
#     return x*x

# print([square(x) for x in myList])

# print([(lambda x: x*x)(number) for number in myList]) #trzeba pamiętać o nawiasie z argumentem (tam gdzie jest number)

# print(x*x for x in myList)


# ZADANIE

names = ['John Johnson', 'Alicja Policja', 'Wladimir Wladymirowicz']

def get_sub_name(name, part):
    partedName = name.split(" ")

    if part == 0:
        return partedName[0]
    else:
        return partedName[1]
    

# print(get_sub_name(names[0], 0))

print([get_sub_name(n, 0) for n in names])
print([get_sub_name(n, 1) for n in names])


print([(lambda name: name.split(" ")[0])(name) for name in names])
print([(lambda name: name.split(" ")[1])(name) for name in names])