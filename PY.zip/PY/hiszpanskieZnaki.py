import tkinter as tk
from tkinter import messagebox

# lista przycisków: (tekst_na_przycisku, co skopiować)
BUTTONS = [
    ("á", "á"),
    ("é", "é"),
    ("í", "í"),
    ("ó", "ó"),
    ("ú", "ú"),
    ("ñ", "ñ"),
    ("Ñ", "Ñ"),
    ("¿", "¿"),
    ("¡", "¡"),
]

def copy_to_clipboard(text):
    root.clipboard_clear()
    root.clipboard_append(text)
    # mały komunikat w tytule, że skopiowano
    status_var.set(f"Skopiowano: {text}")

root = tk.Tk()
root.title("Hiszpańskie znaki")
root.resizable(False, False)

# okno zawsze na wierzchu
root.attributes("-topmost", True)

# ramka na przyciski
frame = tk.Frame(root, padx=10, pady=10)
frame.pack()

for i, (label, value) in enumerate(BUTTONS):
    btn = tk.Button(frame, text=label, width=4, command=lambda v=value: copy_to_clipboard(v))
    btn.grid(row=i // 4, column=i % 4, padx=3, pady=3)

# pasek statusu
status_var = tk.StringVar(value="Kliknij literę, żeby skopiować")
status_label = tk.Label(root, textvariable=status_var, anchor="w")
status_label.pack(fill="x", padx=5, pady=(0,5))

root.mainloop()

close_btn = tk.Button(root, text="Zamknij", command=root.destroy)
close_btn.pack(pady=(0,5))