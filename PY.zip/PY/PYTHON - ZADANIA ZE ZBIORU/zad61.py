# import math
# with open("dane\\61\\ciagi.txt", "r") as file:
#     dataList = []
#     for line in file:
#         dataList.append(line.strip())


#     itemsAmount = []
#     values = []
#     for i in range(len(dataList)):
#         if i % 2 == 0:
#             itemsAmount.append(dataList[i])
#         else:
#             values.append(dataList[i].split(" "))

#     values_int = [[int(x) for x in sublist] for sublist in values]
            
    # artmSequences = []
    # # print(values_int[1])
    
    # for draft in values_int:
    #     difference = draft[1] - draft[0]
    #     is_arithmetic = True
    #     for i in range(2, len(draft)):
    #         if draft[i] - draft[i-1] != difference:
    #             is_arithmetic = False
    #             break
    #     if is_arithmetic:
    #         artmSequences.append(draft)


    # print(len(artmSequences)) #44

    # differences = []
    # for elem in artmSequences:
    #     tempDifference = elem[1] - elem[0]
    #     differences.append(tempDifference)

    # print(max(differences)) #246849

#Zad. 2
    # biggestCubeNumber = []
    # for draft in values_int:
    #     for elem in draft:
    #         root = round(math.pow(elem, 1/3))
    #         if math.pow(root, 3) == elem:
    #             biggestCubeNumber.append(elem)

    # print(biggestCubeNumber)

#Zad. 3
import math
with open("dane\\61\\bledne.txt", "r") as file:
    dataList = []
    for line in file:
        dataList.append(line.strip())


    itemsAmount = []
    values = []
    for i in range(len(dataList)):
        if i % 2 == 0:
            itemsAmount.append(dataList[i])
        else:
            values.append(dataList[i].split(" "))

    values_int = [[int(x) for x in sublist] for sublist in values]

    errors = []
    for draft in values_int:
        difference = draft[1] - draft[0]
        for i in range(2, len(draft)):
            if draft[i] - draft[i-1] != difference:
                errors.append(draft[i])
                break

    print(errors)