with open("dane\\58\\dane_systemy1.txt", "r") as file:
    S1_data = [] # drugi index zawsze jedynka
    for elem in file:
        S1_data.append(elem.strip().split(" "))

with open("dane\\58\\dane_systemy2.txt", "r") as file:
    S2_data = []
    for elem in file:
        S2_data.append(elem.strip().split(" "))

with open("dane\\58\\dane_systemy3.txt", "r") as file:
    S3_data = []
    for elem in file:
        S3_data.append(elem.strip().split(" "))

S1_temp = []
S2_temp = []
S3_temp = []
S1_clock = []
S2_clock = []
S3_clock = []

for i in range(len(S1_data)):
    S1_temp.append(int(S1_data[i][1], 2))
    S1_clock.append(int(S1_data[i][0], 2))

for i in range(len(S2_data)):
    S2_temp.append(int(S2_data[i][1], 4))
    S2_clock.append(int(S2_data[i][0], 4))


for i in range(len(S3_data)):
    S3_temp.append(int(S3_data[i][1], 8))
    S3_clock.append(int(S3_data[i][0], 8))

#Zad. 1
# print("Temperatura minimalna w stacji nr 1:", bin(min(S1_temp))) #-1011
# print("Temperatura minimalna w stacji nr 4:", bin(min(S2_temp))) #-1001100
# print("Temperatura minimalna w stacji nr 3:", bin(min(S3_temp))) #-1001011

errorsCounter = 0
start = 12

for i in range(len(S1_clock)):
    validValue = start + 24 * i
    if S1_clock[i] != validValue and S2_clock[i] != validValue and S3_clock[i] != validValue:
        errorsCounter += 1

#Zad. 2
# print(errorsCounter) #182

recordDays = 1
S1_record = S1_temp[0]
S2_record = S2_temp[0]
S3_record = S3_temp[0]

for i in range(1, len(S1_temp)):
    temp1 = S1_temp[i]
    temp2 = S2_temp[i]
    temp3 = S3_temp[i]

    if_record = False
    if temp1 > S1_record:
        S1_record = temp1
        if_record = True
    if temp2 > S2_record:
        S2_record = temp2
        if_record = True
    if temp3 > S3_record:
        S3_record = temp3
        if_record = True

    if if_record:
        recordDays += 1

#zad. 3
# print(recordDays) #42

import math
maxJump = 0
for i in range(len(S1_data)):
    for j in range(len(S1_data)):
        if i != j:
            t_i = S1_temp[i]
            t_j = S1_temp[j]

            r = (t_i - t_j)**2
            jump = math.ceil(r/abs(i-j))
            if jump > maxJump:
                maxJump = jump

print(maxJump)