import math
with open("dane\\60\\liczby.txt", "r") as file:
    numbers = []
    for line in file:
        numbers.append(int(line))

#Zad. 1
    # counter = 0
    # for elem in numbers:
    #     if elem < 1000:
    #         counter += 1

    # print(counter) #12, 633, 540

#Zad. 2
    # divisors = []
    # for number in numbers:
    #     counter = 0
    #     for i in range(1, number+1):
    #         if number % i == 0:
    #             counter += 1

    #     if counter == 18:
    #         divisors.append(number)

    # print(divisors) # [989532, 131072, 702027, 461817, 17298]


    # divisors = [989532, 131072, 702027, 461817, 17298]
    # for elem in divisors:
    #     divisorsOfSingleNumber = []
    #     for i in range(1, elem+1):
    #         if elem % i == 0:
    #             divisorsOfSingleNumber.append(i)

    #     print(divisorsOfSingleNumber)

#Zad.3
    # math.gcd
    # notCommonDivisors = []
    # for i in range(1, len(numbers)):
    #     if math.gcd(numbers[i-1], numbers[i]) == 1:
    #         notCommonDivisors.append(numbers[i])

    # print(max(notCommonDivisors)) #999037