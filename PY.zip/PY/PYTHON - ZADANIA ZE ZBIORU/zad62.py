import math
with open("dane\\62\\liczby1.txt", "r") as file:
    numbersOct = [int(x) for x in file]
    numbersOctString = [str(x) for x in numbersOct]

    convertedNumbersOct = [int(str(x), 8) for x in numbersOct]
    convertedNumbersOctString = [str(x) for x in convertedNumbersOct]

with open("dane\\62\\liczby2.txt", "r") as file:
    numbersDec = [int(x) for x in file]
    numbersDecString = [str(x) for x in numbersDec]
    convertedNumbersDecToOct = [oct(x) for x in numbersDec]
    convertedNumbersDecToOctString = (str(x) for x in convertedNumbersDecToOct)

#Zad. 1
    # print("Liczba maksymalna:", max(numbersOct), "\nLiczba minimalna:", min(numbersOct)) #777044 1002

#Zad. 2
    # maxLength = 1
    # start = numbersDec[0]
    # currentLength = 1
    # currentStart = numbersDec[0]
    # beforeNumber = numbersDec[0]

    # for i in range(1, len(numbersDec)):
    #     currentNumber = numbersDec[i]
    #     if currentNumber >= beforeNumber: #warunek jaki ma być ciąg (np. niemalejący itp.)
    #         currentLength += 1

    #     if currentLength > maxLength:
    #         maxLength = currentLength
    #         start = currentStart

    #     if currentNumber < beforeNumber:
    #         currentLength = 1
    #         currentStart = currentNumber

    #     beforeNumber = currentNumber

    # print(maxLength, start)

#Zad. 3
    # equals = []
    # for i in range(len(convertedNumbersOct)):
    #     if numbersDec[i] == convertedNumbersOct[i]:
    #         equals.append(i)

    # print(len(equals)) #160

    # biggers = []
    # for i in range(len(convertedNumbersOct)):
    #     if numbersDec[i] < convertedNumbersOct[i]:
    #         biggers.append(i)

    # print(len(biggers)) #357

#Zad. 4
    counter = 0

    for number in convertedNumbersDecToOctString:
        for elem in number:
            if elem == "6":
                counter += 1

    print(counter) #411 #625