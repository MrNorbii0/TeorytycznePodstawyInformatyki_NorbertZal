#biały - 0
#czarny - 1

#bit parzystości = 0 --> parzysta liczba jedynek
#bit parzystości = 1 --> nieparzysta liczba jedynek

import math
with open("dane\\64\\dane_obrazki.txt", "r") as file:
    data = [x.strip() for x in file]

    images = []
    tempImage = []
    for i in range(len(data)):
        if i == 0:
            tempImage.append(data[i])
        elif (i+1)%(21+1) != 0:
            tempImage.append(data[i])
        else:
            images.append(tempImage)
            tempImage = []

    images.append(tempImage)

#Zad. 1
    # counter = 0
    # maxBlackPixels = 0
    # for image in images:
    #     whiteCounter = 0
    #     blackCounter = 0
    #     for i in range(20):
    #         for j in range(20):
    #             if image[i][j] == "0": #JESTEM GENIUSZEM PIERDOLONYM
    #                 whiteCounter += 1
    #             else:
    #                 blackCounter += 1
    #     if blackCounter > whiteCounter:
    #         counter += 1

    #     if blackCounter > maxBlackPixels:
    #         maxBlackPixels = blackCounter
    # print(counter, maxBlackPixels)

#Zad. 2
# counter = 0
# first_recursive_image = None

# for image in images:
#     reverseCounter = 0

#     for j in range(10):
#         row = image[j]
#         if (row[0:10] == row[10:20] and
#             image[j + 10][0:10] == image[j + 10][10:20] and
#             row[0:10] == image[j + 10][0:10]):
#             reverseCounter += 1

#     if reverseCounter == 10:
#         counter += 1
#         if first_recursive_image is None:
#             first_recursive_image = image

# print(counter) #i fajnie

# if first_recursive_image:
#     for row in first_recursive_image:
#         print("".join(row))

#Zad. 3
    

