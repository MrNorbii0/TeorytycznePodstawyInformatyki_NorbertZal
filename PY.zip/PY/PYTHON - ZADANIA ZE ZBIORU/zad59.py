#Zad. 1
# from sympy import primerange

# with open("dane\\59\\liczby.txt", "r") as file:
#     numbers = []
#     for line in file:
#         numbers.append(int(line))

#     firstNumbers = list(primerange(0, max(numbers)))
#     print(firstNumbers)

    # testNumber = [210, 3465, 255255, 1287]
    # results = []

    # for elem in numbers:
    #     i = 0
    #     factors = []
    #     while i < len(firstNumbers):
    #         if elem % firstNumbers[i] == 0:
    #             elem = elem/firstNumbers[i]
    #             print(firstNumbers[i])
    #             factors.append(firstNumbers[i])
    #         else:
    #             i += 1
    #     uniqueFactors = list(set(factors))
    #     results.append(uniqueFactors)
    
    # # print(factors)
    # print(results)

    # counter = 0
    # for elem in results:
    #     if 2 in elem:
    #         pass
    #     else:
    #         if len(elem) == 3:
    #             counter += 1
    
    # print(counter)

#Zad. 2
# with open("dane\\59\\liczby.txt", "r") as file:
#     numbers = []
#     reversedNumbers = []
#     sums = []

#     for line in file:
#         numbers.append(line.strip())

#     for elem in numbers:
#         reversedNumbers.append(elem[::-1])

#     for i in range(len(numbers)):
#         sums.append(str((int(numbers[i]) + int(reversedNumbers[i]))))
    
#     palindromCounter = 0
#     for elem in sums:
#         if elem == elem[::-1]:
#             palindromCounter += 1

#     print(palindromCounter) #181


#Zad. 3
with open("dane\\59\\liczby.txt", "r") as file:
    numbers = []
    for line in file:
        numbers.append(int(line))

    numbersWithPower1 = []
    powers = []
    for number in numbers:
        counter = 0
        while True:
            testNumber = number
            strNumber = str(testNumber)
            product = 1
            for elem in strNumber:
                product *= int(elem)

            # print(product)
            counter += 1
            if product == number or product == 0 or len(str(product)) == 1:
                break
            number = product

        powers.append(counter)
        if counter == 1:
            numbersWithPower1.append(number)
    
    print(min(numbersWithPower1)) #git
    print(max(numbersWithPower1)) #git

    power1 = 0
    power2 = 0
    power3 = 0
    power4 = 0
    power5 = 0
    power6 = 0
    power7 = 0
    power8 = 0
    for elem in powers:
        if elem == 1:
            power1 += 1
        elif elem == 2:
            power2 += 1
        elif elem == 3:
            power3 += 1
        elif elem == 4:
            power4 += 1
        elif elem == 5:
            power5 += 1
        elif elem == 6:
            power6 += 1
        elif elem == 7:
            power7 += 1
        elif elem == 8:
            power8 += 1

    print(power1, power2, power3, power4, power5, power6, power7, power8) #git

