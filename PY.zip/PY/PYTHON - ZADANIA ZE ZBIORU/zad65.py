import math
with open("dane\\65\\dane_ulamki.txt", "r") as file:
    data = [x.strip().split() for x in file]

    # print(data[0][0])

#Zad. 1
    # minValue = int(data[0][0])/int(data[0][1]) #góra/dół
    # indexMinValue = 0
    # for i in range(len(data)):
    #     up = int(data[i][0])
    #     down = int(data[i][1])

    #     value = up/down
    #     if value < minValue:
    #         minValue = value
    #         indexMinValue = i

    # print(data[indexMinValue]) #1 225

#Zad. 2
# counter = 0

# for i in range(len(data)):
#     up = int(data[i][0])
#     down = int(data[i][1])

#     if math.gcd(up, down) == 1:
#         counter += 1

# print(counter) #410

#Zad. 3
# shortest = []
# for i in range(len(data)):
#     up = int(data[i][0])
#     down = int(data[i][1])

#     gcd = math.gcd(up, down)
#     shortestUp = up/gcd

#     shortest.append(shortestUp)

# print(sum(shortest)) #128446

#Zad. 4
b = (math.pow(2,2)*(math.pow(3,2))*(math.pow(5,2))*(math.pow(7,2))*13)
tempList = []

for i in range(len(data)):
    up = int(data[i][0])
    down = int(data[i][1])

    temp = (up*b)/down
    tempList.append(temp)

print(sum(tempList)) #578219135