import math
with open("dane\\63\\ciagi.txt", "r") as file:
    data = [x.strip() for x in file]
    dataInt = [int(x) for x in data]
    dataDec = [int(x, 2) for x in data]

#Zad. 1
    # evenSeq = []
    # for elem in data:
    #     if len(elem) % 2 == 0:
    #         evenSeq.append(elem)

    # cyclicSeq = []

    # for elem in evenSeq:
    #     half = int(len(elem)/2)
    #     if elem[0:half] == elem[half:len(elem)]:
    #         cyclicSeq.append(elem)

    # print(cyclicSeq) #git

#Zad. 2
    # counter = 0
    # for elem in data:
    #     if "11" not in elem:
    #         counter += 1

    # print(counter) #93

#Zad. 3
    from sympy import primerange

        
    halfFirst = []
    for testNumber in dataDec:
        currentNumber = testNumber
        firstNumbers = list(primerange(0, testNumber))

        counter = 0
        while testNumber != 1:
            found = False
            for elem in firstNumbers:
                if testNumber % elem == 0:
                    testNumber = testNumber/elem
                    # print(testNumber)
                    counter += 1
                    found = True
                    break

            if not found:
                break

            if counter > 2:
                break

        if counter == 2:
            halfFirst.append(currentNumber)

    print(len(halfFirst)) #259
    print(min(halfFirst)) #6
    print(max(halfFirst)) #248667