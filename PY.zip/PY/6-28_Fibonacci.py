# 0 1 1 2 3 5 8 13 21 34
import math

start_point = 0
how_many_numbers = 10
fibList = []

if start_point == 0:
    fibList = [1]
else:
    fibList = [start_point]

for i in range(0, how_many_numbers):
    fibList.append(fibList[i]+fibList[i-1])

if start_point == 0:
    print([0, 1] + fibList)
else:
    print(fibList)
