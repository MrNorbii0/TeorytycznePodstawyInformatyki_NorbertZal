def f(n):
    fib = [1]
    
    i = 0
    while True:
        current_fib = fib[i-1] + fib[i]
        fib.append(current_fib)

        if current_fib >= n:
            break

        i += 1

    if n in fib:
        return True
    else:
        return False

print(f(7))